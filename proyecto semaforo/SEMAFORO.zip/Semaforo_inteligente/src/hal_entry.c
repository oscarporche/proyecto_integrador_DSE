/***********************************************************************************************************************
 * Copyright [2015-2017] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 * 
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : hal_entry.c
* Description  : This is a very simple example application that blinks all LEDs on a board.
***********************************************************************************************************************/

#include "hal_data.h"

/*******************************************************************************************************************//**
 * @brief  Blinky example application

 *
 * Blinks all leds at a rate of 1 second using the software delay function provided by the BSP.
 * Only references two other modules including the BSP, IOPORT.
 *
 **********************************************************************************************************************/
 const bsp_delay_units_t bsp_delay_units=BSP_DELAY_UNITS_MILLISECONDS;
 uint32_t intermitencia=4;
 uint32_t delayBLINK=500;
 uint32_t delay_PER=1500;
 uint32_t delay_CAR=1500;
 uint32_t delay=5000;

void hal_entry(void) {
    g_external_irq10.p_api->open(g_external_irq10.p_ctrl,g_external_irq10.p_cfg);
    g_external_irq11.p_api->open(g_external_irq11.p_ctrl,g_external_irq11.p_cfg);

    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_HIGH) ;
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_HIGH) ;



    while(1)
      {


          g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW) ;

      }


/*

              }*/


}
void button_callback_SW4(external_irq_callback_args_t*p_args)
{

       blink_Green();
       g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_HIGH);
       blink_YELLOW();
       g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_LOW);
       R_BSP_SoftwareDelay(delay_PER, bsp_delay_units);// Delay;
       blink_Red();
       R_BSP_SoftwareDelay(delay, bsp_delay_units);// Delay;
}

void button_callback_SW5(external_irq_callback_args_t*p_args)
{
       blink_Green();
       g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_HIGH);
       blink_YELLOW();
       g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_LOW);
       R_BSP_SoftwareDelay(delay_CAR, bsp_delay_units);// Delay
       blink_Red();
       R_BSP_SoftwareDelay(delay_CAR, bsp_delay_units);// Delay
       R_BSP_SoftwareDelay(delay, bsp_delay_units);// Delay;
}


void blink_Green()
{
    for(intermitencia=0;intermitencia<=5;intermitencia++)
              {
               g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW);
               R_BSP_SoftwareDelay(delayBLINK, bsp_delay_units);// Delay
               g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_HIGH);
               R_BSP_SoftwareDelay(delayBLINK, bsp_delay_units);// Delay
              }
}
void blink_Red()
             {
    for(intermitencia=0;intermitencia<=5;intermitencia++) {
        g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_LOW);
        R_BSP_SoftwareDelay(delayBLINK, bsp_delay_units);// Delay
        g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_HIGH);
        R_BSP_SoftwareDelay(delayBLINK, bsp_delay_units);// Delay
    }
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW) ;
             }

void blink_YELLOW()
             {
    for(intermitencia=0;intermitencia<=5;intermitencia++)
    {
        g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_LOW);
        R_BSP_SoftwareDelay(delayBLINK, bsp_delay_units);// Delay
        g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_HIGH);
        R_BSP_SoftwareDelay(delayBLINK, bsp_delay_units);// Delay
    }
             }








