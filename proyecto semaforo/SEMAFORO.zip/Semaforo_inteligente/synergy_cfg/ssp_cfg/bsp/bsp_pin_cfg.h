/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#include "r_ioport.h"
extern const ioport_cfg_t g_bsp_pin_cfg; /* S7G2-SK.pincfg */
#endif /* BSP_PIN_CFG_H_ */
